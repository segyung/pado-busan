export const normalizePhone=v=>String(v||"").replace(/[^0-9]/g,"");
export const getSessionPhone=()=>localStorage.getItem("pado_member_phone")||"";
export const setSessionPhone=p=>localStorage.setItem("pado_member_phone",normalizePhone(p));
export const clearSessionPhone=()=>localStorage.removeItem("pado_member_phone");
export const isCrew=()=>localStorage.getItem("pado_crew")==="yes";
export const setCrew=v=>v?localStorage.setItem("pado_crew","yes"):localStorage.removeItem("pado_crew");

export const CURRENT_COHORT=1;
export const COHORT_LABEL=`${CURRENT_COHORT}기`;

export function calcActivityScore(s={}){
  return (s.joined||0)*20+(s.created||0)*30+(s.hostedDone||0)*20+(s.reviews||0)*10+(s.photos||0)*5+(s.club||0)*15+(s.invited||0)*50+(s.likes||0)*1+(s.comments||0)*2+(s.extra||0);
}
export function levelFromStats(s={}){
  const score=calcActivityScore(s);
  if(score>=3000)return{icon:"🌊",name:"파도",level:6,score,next:null};
  if(score>=1500)return{icon:"🌊💦",name:"물보라",level:5,score,next:3000};
  if(score>=700)return{icon:"🌊",name:"너울",level:4,score,next:1500};
  if(score>=300)return{icon:"🌊",name:"물결",level:3,score,next:700};
  if(score>=100)return{icon:"✨",name:"윤슬",level:2,score,next:300};
  return{icon:"💧",name:"물방울",level:1,score,next:100};
}
export function badgesFromStats(s={},member={}){
  const b=[];
  if(member?.status==="approved")b.push("💧 첫 물결");
  if((s.joined||0)>=1)b.push("👋 첫 만남");
  if(member?.name&&member?.homeArea)b.push("📱 프로필 완성");
  if((s.reviews||0)>=1)b.push("📝 첫 후기");
  if((s.joined||0)>=5)b.push("🥉 5회 참여");
  if((s.joined||0)>=10)b.push("🥈 10회 참여");
  if((s.joined||0)>=20)b.push("🥇 20회 참여");
  if((s.joined||0)>=50)b.push("💎 50회 참여");
  if((s.created||0)>=1)b.push("🎤 첫 밋업 개설");
  if((s.created||0)>=5)b.push("🚩 5회 개설");
  if((s.created||0)>=10)b.push("⭐ 10회 개설");
  if((s.lightning||0)>=1)b.push("⚡ 번개 참여");
  if((s.lightning||0)>=5)b.push("🍻 번개왕");
  if((s.reviews||0)>=5)b.push("📸 기록러");
  if((s.reviews||0)>=10)b.push("📝 후기왕");
  if((s.invited||0)>=1)b.push("💙 친구 초대");
  if((s.invited||0)>=5)b.push("🌊 물결 만들기");
  if((s.waiting||0)>=1)b.push("⏳ 대기 경험");
  if(member?.cohort)b.push(`🌊 ${member.cohort}기 멤버`);
  return [...new Set([...(member?.badges||[]),...b])];
}
